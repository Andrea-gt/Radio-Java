import org.junit.Test;

import static org.junit.Assert.assertEquals;
public class TestJUnitAM {
   
	@Test
   public void test_cambiarEmisora() {
	  float num; 
	  for(int i=0; i < 50; i++){
		  num = (float)(500 + i*10); //Se probar� desde 500, aumentando en incrementos de 10
		  
		  //Esta es la parte del m�todo original a testear
		  if(num > 530){
			  num -= 10;
	      } else {
	    	  num = 1610;
	      }
		  
		  //Test
		  assertEquals(true, num <= 1610 && num >= 530); 
		  //Se verifica que todas las entradas del array est�n dentro del intervalo de las emisoras AM
		  //luego de hacer la reducci�n
	  }
   }
}