import org.junit.Test;

import static org.junit.Assert.assertEquals;
public class TestJUnitFM {
   
	@Test
   public void test_cambiarEmisoraFM() {
	  float num;
	  for(int i=0; i < 70; i++){
		  num = (float)(87.9 + i*0.2); //Se prueban numeros desde 87.9 que incrementan en intervalos de 0.2
		  
		  //Esta es la parte del m�todo original a testear
		  if(num < 107.9){
			  num += 0.2;
	      } else {
	    	  num = (float)87.9;
	      }
		  
		  //Test
		  assertEquals(true, num <= 107.9 && num >= 87.9); 
		  //Se verifica que todas las entradas est�n dentro del intervalo de las emisoras AM luego de hacer la reducci�n
	  }
   }
}
