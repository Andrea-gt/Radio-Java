import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {
   public static void main(String[] args) {
      Result resultAM = JUnitCore.runClasses(TestJUnitAM.class);
      Result resultFM = JUnitCore.runClasses(TestJUnitFM.class);
      Result resultGetFM = JUnitCore.runClasses(TestJUnitGetFM.class);
      for (Failure failure : resultAM.getFailures()) {
         System.out.println(failure.toString());
      }
      System.out.println("Resultado de cambio de emisora AM: "+((resultAM.wasSuccessful())?"Exito":"Error"));
      
      for (Failure failure : resultFM.getFailures()) {
          System.out.println(failure.toString());
       }
      System.out.println("Resultado de cambio de emisora FM: "+((resultFM.wasSuccessful())?"Exito":"Error"));
      
      for (Failure failure : resultGetFM.getFailures()) {
          System.out.println(failure.toString());
       }
      System.out.println("Resultado de verificacion de frecuencia FM: "+((resultGetFM.wasSuccessful())?"Exito":"Error"));
   }
} 