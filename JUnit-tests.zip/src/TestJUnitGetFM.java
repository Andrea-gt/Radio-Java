import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestJUnitGetFM {
	
	@Test
	public void TestGetFM(){
		
		float num;
		
		for(int i=0; i<100; i++){ 
			num = (float)(i*0.2); //Se verifica que todas las entradas impares en intervalos de 0.2 sean clasificadas como correctas
			assertEquals(0.1, num % 0.2, 0.02); //Se toma el numero % 0.2 y, si el residuo es 0.1 con intervalo de error de 0.02, se toma como exito
		}
	}
	
}

